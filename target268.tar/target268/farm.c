/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_458(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_330()
{
    return 2428995912U;
}

void setval_288(unsigned *p)
{
    *p = 3351742792U;
}

void setval_342(unsigned *p)
{
    *p = 3281031256U;
}

unsigned getval_415()
{
    return 3787671694U;
}

unsigned getval_169()
{
    return 3251079496U;
}

void setval_251(unsigned *p)
{
    *p = 1150534488U;
}

unsigned getval_253()
{
    return 2425393176U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_338(unsigned *p)
{
    *p = 3531918984U;
}

unsigned getval_434()
{
    return 2425671305U;
}

void setval_328(unsigned *p)
{
    *p = 2463205825U;
}

void setval_119(unsigned *p)
{
    *p = 3526938253U;
}

unsigned addval_213(unsigned x)
{
    return x + 2445445577U;
}

unsigned getval_404()
{
    return 3674260105U;
}

void setval_182(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_442()
{
    return 3526413961U;
}

unsigned addval_294(unsigned x)
{
    return x + 3677930137U;
}

unsigned getval_361()
{
    return 3674788249U;
}

unsigned addval_418(unsigned x)
{
    return x + 3767126031U;
}

unsigned getval_205()
{
    return 2447411528U;
}

unsigned getval_472()
{
    return 3281047177U;
}

unsigned getval_158()
{
    return 3227566729U;
}

unsigned getval_191()
{
    return 3250751758U;
}

unsigned getval_396()
{
    return 3372798409U;
}

unsigned addval_321(unsigned x)
{
    return x + 3682914761U;
}

void setval_372(unsigned *p)
{
    *p = 3284306188U;
}

unsigned addval_440(unsigned x)
{
    return x + 3526935177U;
}

unsigned addval_198(unsigned x)
{
    return x + 3526938249U;
}

unsigned addval_268(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_379(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_290(unsigned x)
{
    return x + 3465272132U;
}

void setval_291(unsigned *p)
{
    *p = 3378565513U;
}

unsigned getval_250()
{
    return 3767126017U;
}

unsigned addval_302(unsigned x)
{
    return x + 2425409929U;
}

unsigned addval_266(unsigned x)
{
    return x + 3082998153U;
}

unsigned addval_494(unsigned x)
{
    return x + 3286280520U;
}

unsigned getval_371()
{
    return 3281306249U;
}

unsigned addval_499(unsigned x)
{
    return x + 3353381192U;
}

void setval_224(unsigned *p)
{
    *p = 3223375499U;
}

unsigned getval_106()
{
    return 3677933961U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
